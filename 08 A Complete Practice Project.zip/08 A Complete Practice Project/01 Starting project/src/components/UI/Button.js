import React from 'react';

// css module
import classes from './Button.module.css';

// Button component
const Button = (props) => {
  return (
    <button
      className={classes.button}
      type={props.type || 'button'} // type => set incoming prop type(If it is undefined set as 'button')
      onClick={props.onClick}
    >
      {props.children}
    </button>
  );
};

export default Button;
