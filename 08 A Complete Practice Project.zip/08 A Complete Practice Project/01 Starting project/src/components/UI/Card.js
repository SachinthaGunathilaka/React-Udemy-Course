import React from 'react';

// import module
import classes from './Card.module.css';

// Card Comp
const Card = (props) => {
  // set className as classes.card + incoming class from the prop (2 css classes)
  return <div className={`${classes.card} ${props.className}`}>{props.children}</div>;
  // Content is the props.children
};

export default Card;
