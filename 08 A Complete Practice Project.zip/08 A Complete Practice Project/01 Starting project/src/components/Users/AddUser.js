import React from 'react';

import Card from '../UI/Card';
import Button from '../UI/Button';
import classes from './AddUser.module.css';

const AddUser = (props) => {
  // addUserHandler function
  const addUserHandler = (event) => {
    event.preventDefault();
  };

  return (
      // Card component (User defined), className is a prop
    <Card className={classes.input}>
      {/* Call  addUserHandler when click submit button*/}
      <form onSubmit={addUserHandler}>
        {/* htmlFor => for in html*/}
        <label htmlFor="username">Username</label>
        <input id="username" type="text" />
        <label htmlFor="age">Age (Years)</label>
        <input id="age" type="number" />
        {/* User defined Button, type is a prop*/}
        <Button type="submit">Add User</Button>
      </form>
    </Card>
  );
};

export default AddUser;
