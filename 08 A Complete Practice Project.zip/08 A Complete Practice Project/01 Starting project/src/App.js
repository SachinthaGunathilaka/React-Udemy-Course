// Check App.js, AddUser.js, Card.js, Button.js

import React from 'react';

import AddUser from './components/Users/AddUser';

function App() {
  return (
    <div>
      {/* AddUser component */}
      <AddUser />
    </div>
  );
}

export default App;
