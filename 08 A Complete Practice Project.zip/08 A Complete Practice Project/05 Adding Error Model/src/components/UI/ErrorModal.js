import React from 'react';

import Card from './Card';
import Button from './Button';
import classes from './ErrorModal.module.css';


// Error Modal (No need to consider about css, We can use bootstrap or any other to get Styled components)
const ErrorModal = (props) => {
  return (
    <div>
          {/*
            This is a layer between the model and the addUser (Layer is in entire screen)
            If we click on that layer, exit
           */}
          <div className={classes.backdrop} onClick={props.onConfirm}/>

          <Card className={classes.modal}>
            <header className={classes.header}>
                {/* Title */}
                <h2>{props.title}</h2>
            </header>
            <div className={classes.content}>
                {/* Message */}
                <p>{props.message}</p>
            </div>
            <footer className={classes.actions}>
              {/* Okay button (execute func in the prop) */}
              <Button onClick={props.onConfirm}>Okay</Button>
            </footer>
          </Card>
    </div>
  );
};

export default ErrorModal;
