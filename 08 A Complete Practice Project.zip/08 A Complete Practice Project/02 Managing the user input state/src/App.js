import React from 'react';

import AddUser from './components/Users/AddUser';

function App() {
  return (
    <div>
      <AddUser />
    </div>
  );
}

export default App;
