// Check App.js, AddUser.js, UserList.js

import React, { useState } from 'react';

import AddUser from './components/Users/AddUser';
import UsersList from './components/Users/UsersList';

function App() {
  const [usersList, setUsersList] = useState([]);

  // Passing func (Takes name, age as args)
  const addUserHandler = (uName, uAge) => {
    // add user to state
    setUsersList((prevUsersList) => {
      return [
        ...prevUsersList,
        { name: uName, age: uAge, id: Math.random().toString() },
          // generate ID also
      ];
    });
  };

  return (
    <div>
      <AddUser onAddUser={addUserHandler} />

      {/* List of users */}
      <UsersList users={usersList} />
    </div>
  );
}

export default App;
