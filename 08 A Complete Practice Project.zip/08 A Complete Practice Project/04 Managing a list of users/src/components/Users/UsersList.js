import React from 'react';

import Card from '../UI/Card';
import classes from './UsersList.module.css';

// UsersList Component
const UsersList = (props) => {
  return (
      // User defined comp (className is a prop)
    <Card className={classes.users}>
      <ul>
        {props.users.map((user) => (
          //  Previously we use component instead of li (We pass key to the component as a prop)
          //  In here we set key in li
          <li key={user.id}>
            {user.name} ({user.age} years old)
          </li>
        ))}
      </ul>
    </Card>
  );
};

export default UsersList;
