// Import useRef hook
import React, { useState, useRef } from 'react';

import Card from '../UI/Card';
import Button from '../UI/Button';
import ErrorModal from '../UI/ErrorModal';
import Wrapper from '../Helpers/Wrapper';
import classes from './AddUser.module.css';

const AddUser = (props) => {

  // Initialize refs for input name and age (No default values here - so initially undefined)
  /* After connecting ref to a element, refname.current => can access the actual dom element
     Previously in every onChange we update the state and we use 2 way binding. When submitting we set state to empty.
     By using refs, we can remove state for inputs, onChange methods,  2 way binding.
   */
  const nameInputRef = useRef();
  const ageInputRef = useRef();

  const [error, setError] = useState();

  const addUserHandler = (event) => {
    event.preventDefault();

    // Get values in the dom elements
    const enteredName = nameInputRef.current.value;
    const enteredUserAge = ageInputRef.current.value;
    if (enteredName.trim().length === 0 || enteredUserAge.trim().length === 0) {
      setError({
        title: 'Invalid input',
        message: 'Please enter a valid name and age (non-empty values).',
      });
      return;
    }
    if (+enteredUserAge < 1) {
      setError({
        title: 'Invalid age',
        message: 'Please enter a valid age (> 0).',
      });
      return;
    }
    props.onAddUser(enteredName, enteredUserAge);

    // set inputs to empty (Rarely use this, Usually we should not manipulate the dom, React should do this)
    // If we only want to read data, refs is the best way
    nameInputRef.current.value = '';
    ageInputRef.current.value = '';
  };

  const errorHandler = () => {
    setError(null);
  };

  return (
    <Wrapper>
      {error && (
        <ErrorModal
          title={error.title}
          message={error.message}
          onConfirm={errorHandler}
        />
      )}
      <Card className={classes.input}>
        <form onSubmit={addUserHandler}>
          <label htmlFor="username">Username</label>

          {/* using ref connect nameInputRef to this element */}
          <input id="username" type="text" ref={nameInputRef} />
          <label htmlFor="age">Age (Years)</label>

          {/* using ref connect ageInputRef to this element */}
          <input id="age" type="number" ref={ageInputRef} />
          <Button type="submit">Add User</Button>
        </form>
      </Card>
    </Wrapper>
  );
};

export default AddUser;
