// Card css file
import './Card.css';

// Card is a component which includes card class. (As a wrapper component)
function Card(props) {
  // card class defined in Card.css(rounded border with a shadow )
  // className is a prop. (It holds another class in some other css file)
  const classes = 'card ' + props.className; // 2 css classes

  // props.children => content between opening and closing tag of Card component (No need to pass that, it will be auto taken)
  // classes => card some_other_class
  return <div className={classes}>{props.children}</div>;
}

export default Card;
