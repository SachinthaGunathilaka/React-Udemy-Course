import ExpenseDate from './ExpenseDate';
// Import Card
import Card from './Card';
import './ExpenseItem.css';

function ExpenseItem(props) {
  return (
      //  Use Card as the wrapper (Card is a component, So className is a prop)
      //  Pass className as a prop (expenses-item includes styles for ExpenseDate)
    <Card className='expense-item'>
      <ExpenseDate date={props.date} />
      <div className='expense-item__description'>
        <h2>{props.title}</h2>
        <div className='expense-item__price'>${props.amount}</div>
      </div>
    </Card>
  );
}

export default ExpenseItem;
