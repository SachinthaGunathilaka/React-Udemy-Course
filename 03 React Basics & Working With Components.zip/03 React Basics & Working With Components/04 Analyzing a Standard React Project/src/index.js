// Execution begins from index.js file

// react-dom is a library, ReactDOM is a object export from react-dom lib (We can omit extension for .js files)
import ReactDOM from 'react-dom';

// In normal js, this is invalid syntax
// In react it says that import index.css to the overall application (main css file)
import './index.css';

// App is a component
import App from './App'; // ./ => relative path (Same directory)

// In react we can include html inside js file
ReactDOM.render(<App />, document.getElementById('root'));

// Before it goes to browser, all the react codes will be transformed as normal codes