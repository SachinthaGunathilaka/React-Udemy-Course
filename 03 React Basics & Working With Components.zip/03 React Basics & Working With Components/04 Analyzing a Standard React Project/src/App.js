// Check app.js, index.js, index.html


/*
    JSX => Javascript XML (Html inside Js)
    In react we can use JSX. Npm start process will convert this JSX into browser friendly code.
 */


// App is a component
function App() {
  return (
    <div>
      <h2>Let's get started!</h2>
    </div>
  );
}

export default App;
