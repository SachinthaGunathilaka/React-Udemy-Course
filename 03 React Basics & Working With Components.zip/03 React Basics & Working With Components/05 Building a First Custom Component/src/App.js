// check App.js, ExpenseItem.js

// import custom component
import ExpenseItem from './components/ExpenseItem';

// inbuilt html elements => lowercase
// Our components => start from capital
function App() {
  return (
    <div>
      <h2>Let's get started!</h2>
      <ExpenseItem></ExpenseItem>
    </div>
  );
}

export default App;
