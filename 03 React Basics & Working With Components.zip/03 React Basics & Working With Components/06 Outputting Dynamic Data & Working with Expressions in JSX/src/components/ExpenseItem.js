import './ExpenseItem.css';

function ExpenseItem() {
  // variables to hold data
  const expenseDate = new Date(2021, 2, 28);
  const expenseTitle = 'Car Insurance';
  const expenseAmount = 294.67;

  return (
    //  Use { } to add JS code inside html elememts
    <div className='expense-item'>
      {/* toISOString() is used to convert Date object to string */}
      <div>{expenseDate.toISOString()}</div>
      <div className='expense-item__description'>
        <h2>{expenseTitle}</h2>
        <div className='expense-item__price'>${expenseAmount}</div>
      </div>
    </div>
  );
}

export default ExpenseItem;
