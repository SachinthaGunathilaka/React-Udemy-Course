import ExpenseDate from './ExpenseDate';
import './ExpenseItem.css';

// props is just a name, Can use any name
function ExpenseItem(props) {
  return (
    <div className='expense-item'>
      {/* ExpenseDate Component with props (Forward date), No closing tag, We use self closing tag*/}
      <ExpenseDate date={props.date} />
      <div className='expense-item__description'>
        <h2>{props.title}</h2>
        <div className='expense-item__price'>${props.amount}</div>
      </div>
    </div>
  );
}

export default ExpenseItem;
