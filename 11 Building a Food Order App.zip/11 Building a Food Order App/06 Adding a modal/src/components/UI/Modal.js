import { Fragment } from "react";
import ReactDOM from "react-dom";

import classes from "./Modal.module.css";

// Intermediate Layer
const Backdrop = (props) => {
  return <div className={classes.backdrop} />;
};

// Actual model
const ModalOverlay = (props) => {
  return (
    <div className={classes.modal}>
      {/* props.children set as the model content */}
      <div className={classes.content}>{props.children}</div>
    </div>
  );
};

// dom element for model
const portalElement = document.getElementById("overlays");

const Modal = (props) => {
  return (
    <Fragment>
      {/* intermediate layer */}
      {ReactDOM.createPortal(<Backdrop />, portalElement)}
      {/* Modal content, pass props.children */}
      {ReactDOM.createPortal(
        <ModalOverlay>{props.children}</ModalOverlay>,
        portalElement
      )}
    </Fragment>
  );
};

export default Modal;
