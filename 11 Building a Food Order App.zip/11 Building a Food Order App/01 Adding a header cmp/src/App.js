// Check App.js, Header.js, HeaderCartButton.js, CartIcon.js

// Directly import React Fragment
import { Fragment } from "react";

import Header from "./components/Layout/Header";

function App() {
  return (
    // Header comp
    <Fragment>
      <Header />
    </Fragment>
  );
}

export default App;
