import classes from "./Card.module.css";

// Custom component with props.children
const Card = (props) => {
  return <div className={classes.card}>{props.children}</div>;
};

export default Card;
