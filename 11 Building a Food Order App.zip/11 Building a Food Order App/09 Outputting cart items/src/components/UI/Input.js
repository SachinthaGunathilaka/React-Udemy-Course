import React from "react";

import classes from "./Input.module.css";

// Forwarding refs (We use ref argument)
const Input = React.forwardRef((props, ref) => {
  return (
    <div className={classes.input}>
      <label htmlFor={props.input.id}>{props.label}</label>
      {/* Set actual ref */}
      <input ref={ref} {...props.input} />
    </div>
  );
});

export default Input;
