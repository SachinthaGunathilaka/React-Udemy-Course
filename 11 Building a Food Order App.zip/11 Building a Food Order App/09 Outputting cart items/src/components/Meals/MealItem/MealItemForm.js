import { useRef, useState } from "react";

import Input from "../../UI/Input";
import classes from "./MealItemForm.module.css";

const MealItemForm = (props) => {
  // Validation state
  const [amountIsValid, setAmountIsValid] = useState(true);

  // We use ref to get input value (Alternative to this is 2 way binding)
  const amountInputRef = useRef();

  // When submitting form
  const submitHandler = (event) => {
    event.preventDefault();

    // get input value using prop (Forwarding prop)
    const enteredAmount = amountInputRef.current.value;
    const enteredAmountNumber = +enteredAmount; // convert to integer

    // validation
    if (
      enteredAmount.trim().length === 0 ||
      enteredAmountNumber < 1 ||
      enteredAmountNumber > 5
    ) {
      setAmountIsValid(false); // set validation state to false
      return;
    }

    // call func in the props (Cannot use context and add to cart item, because we only have amount data)
    props.onAddToCart(enteredAmountNumber);
  };

  return (
    //
    <form className={classes.form} onSubmit={submitHandler}>
      <Input
        // set ref
        /*
            This is a custom component. Ref should be used in in-build html elements.
            So we need to forward this ref to actual element. (Check inside Input comp)
         */
        ref={amountInputRef}
        label="Amount"
        input={{
          id: "amount_" + props.id,
          type: "number",
          min: "1",
          max: "5",
          step: "1",
          defaultValue: "1",
        }}
      />
      <button>+ Add</button>
      {/* Error message */}
      {!amountIsValid && <p>Please enter a valid amount (1-5).</p>}
    </form>
  );
};

export default MealItemForm;
