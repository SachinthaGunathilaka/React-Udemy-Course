// Check App.js, Header.js, HeaderCartButton.js, Cart.js, Modal.js

import { Fragment, useState } from "react";

import Header from "./components/Layout/Header";
import Meals from "./components/Meals/Meals";
import Cart from "./components/Cart/Cart";

function App() {
  // State for cart button
  const [cartIsShown, setCartIsShown] = useState(false);

  // cart button handling funcs
  const showCartHandler = () => {
    setCartIsShown(true);
  };

  const hideCartHandler = () => {
    setCartIsShown(false);
  };

  return (
    <Fragment>
      {/* Show cart dynamically, pass close button handler as a prop */}
      {cartIsShown && <Cart onClose={hideCartHandler} />}
      {/* pass cart button handling func as a prop */}
      <Header onShowCart={showCartHandler} />
      <main>
        <Meals />
      </main>
    </Fragment>
  );
}

export default App;
