import classes from "./Input.module.css";

// Input Component
/* 
    props => {
         label = "label",
         input = {
            key = "value",
             . . . . .
         }
    }
*/

const Input = (props) => {
  return (
    <div className={classes.input}>
      {/* Get id and label of the meal */}
      <label htmlFor={props.input.id}>{props.label}</label>
      {/* Set all key value pairs in props.input to input tag */}
      <input {...props.input} />
    </div>
  );
};

export default Input;
