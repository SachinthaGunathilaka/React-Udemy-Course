import { useReducer } from "react";

import CartContext from "./cart-context";

// default values for the state
const defaultCartState = {
  items: [],
  totalAmount: 0,
};

// Reducer function
const cartReducer = (state, action) => {
  // For add to cart
  if (action.type === "ADD") {
    // Not checking whether the item already exists

    // concat will return new array (push => add to same array)
    // we dont want to update previous snapshot of the state here. So we cannot use push
    const updatedItems = state.items.concat(action.item);
    const updatedTotalAmount =
      state.totalAmount + action.item.price * action.item.amount;
    // return new state
    return {
      items: updatedItems,
      totalAmount: updatedTotalAmount,
    };
  }
  // set default values
  return defaultCartState;
};

const CartProvider = (props) => {
  // state (Reducer)                                              // default values
  const [cartState, dispatchCartAction] = useReducer(
    cartReducer,
    defaultCartState
  );

  // add to cart
  const addItemToCartHandler = (item) => {
    // call reducer func
    dispatchCartAction({ type: "ADD", item: item });
    // item => taken from the child
  };

  // remove from cart
  const removeItemFromCartHandler = (id) => {
    dispatchCartAction({ type: "REMOVE", id: id });
  };

  // passing values to context
  const cartContext = {
    items: cartState.items,
    totalAmount: cartState.totalAmount,
    addItem: addItemToCartHandler,
    removeItem: removeItemFromCartHandler,
  };

  return (
    // pass values to context
    <CartContext.Provider value={cartContext}>
      {props.children}
    </CartContext.Provider>
  );
};

export default CartProvider;
