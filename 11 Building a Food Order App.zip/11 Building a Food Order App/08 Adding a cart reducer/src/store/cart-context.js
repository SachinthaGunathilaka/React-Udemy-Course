import React from "react";

// Context
const CartContext = React.createContext({
  // Default values
  items: [],
  totalAmount: 0,
  addItem: (item) => {},
  removeItem: (id) => {},
});

export default CartContext;
