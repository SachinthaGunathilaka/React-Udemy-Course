import { useReducer } from "react";

import CartContext from "./cart-context";

const defaultCartState = {
  items: [],
  totalAmount: 0,
};

const cartReducer = (state, action) => {
  // Add item (If item exist only amount will be increased)
  if (action.type === "ADD") {
    // update total amount
    const updatedTotalAmount =
      state.totalAmount + action.item.price * action.item.amount;

    // get index of the adding item
    const existingCartItemIndex = state.items.findIndex(
      (item) => item.id === action.item.id
    );
    // get already exist item (If not exist it will be null)
    const existingCartItem = state.items[existingCartItemIndex];
    let updatedItems;

    // If item already exists
    if (existingCartItem) {
      // only change amount of the existing item
      const updatedItem = {
        ...existingCartItem,
        amount: existingCartItem.amount + action.item.amount,
      };

      // copy items array (because we are not editing existing state)
      updatedItems = [...state.items];
      updatedItems[existingCartItemIndex] = updatedItem;
    } else {
      // If item does not exist, add whole item
      updatedItems = state.items.concat(action.item);
    }

    // set state
    return {
      items: updatedItems,
      totalAmount: updatedTotalAmount,
    };
  }
  // Remove item
  if (action.type === "REMOVE") {
    // get index of the removing item by id
    const existingCartItemIndex = state.items.findIndex(
      (item) => item.id === action.id
    );
    // get removing item
    const existingItem = state.items[existingCartItemIndex];
    // set new total
    const updatedTotalAmount = state.totalAmount - existingItem.price;
    let updatedItems;
    // if the amount is 1 remove item from cart
    if (existingItem.amount === 1) {
      updatedItems = state.items.filter((item) => item.id !== action.id);
    } else {
      // Else decrease amount by 1
      const updatedItem = { ...existingItem, amount: existingItem.amount - 1 };
      updatedItems = [...state.items]; // copy state
      updatedItems[existingCartItemIndex] = updatedItem;
    }
    // set state
    return {
      items: updatedItems,
      totalAmount: updatedTotalAmount,
    };
  }

  return defaultCartState;
};

const CartProvider = (props) => {
  const [cartState, dispatchCartAction] = useReducer(
    cartReducer,
    defaultCartState
  );

  // item add dispatch func (get item from child)
  const addItemToCartHandler = (item) => {
    dispatchCartAction({ type: "ADD", item: item });
  };

  // item remove dispatch func(get id from child)
  const removeItemFromCartHandler = (id) => {
    dispatchCartAction({ type: "REMOVE", id: id });
  };

  const cartContext = {
    items: cartState.items,
    totalAmount: cartState.totalAmount,
    addItem: addItemToCartHandler,
    removeItem: removeItemFromCartHandler,
  };

  return (
    <CartContext.Provider value={cartContext}>
      {props.children}
    </CartContext.Provider>
  );
};

export default CartProvider;
