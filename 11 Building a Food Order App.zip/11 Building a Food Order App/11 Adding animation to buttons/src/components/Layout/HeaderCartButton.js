import { useContext, useEffect, useState } from "react";

import CartIcon from "../Cart/CartIcon";
import CartContext from "../../store/cart-context";
import classes from "./HeaderCartButton.module.css";

const HeaderCartButton = (props) => {
  /*
    button highlight state
    we use state, because when items changing useEffect will be run.
    inside useEffect we change state, so whole component will be re evaluated.
    So the animation will play.
   */
  const [btnIsHighlighted, setBtnIsHighlighted] = useState(false);
  const cartCtx = useContext(CartContext);

  const { items } = cartCtx;

  const numberOfCartItems = items.reduce((curNumber, item) => {
    return curNumber + item.amount;
  }, 0);

  // Dynamically add animation class (Animation plays only when we add the class first time)
  const btnClasses = `${classes.button} ${
    btnIsHighlighted ? classes.bump : ""
  }`;

  // when items array changed this func will be re evaluated (Animation will be played)
  useEffect(() => {
    if (items.length === 0) {
      return;
    }
    // if any item exits

    // set button highlight to true
    setBtnIsHighlighted(true);

    // Animation duration is 300ms, When reloading page animation will play, if we want to play it again we need to remove class and add again.
    const timer = setTimeout(() => {
      // after 300ms set button highlight state to false.
      setBtnIsHighlighted(false);
    }, 300);

    // clean up function (Good practice)
    return () => {
      clearTimeout(timer);
    };
  }, [items]);

  return (
    <button className={btnClasses} onClick={props.onClick}>
      <span className={classes.icon}>
        <CartIcon />
      </span>
      <span>Your Cart</span>
      <span className={classes.badge}>{numberOfCartItems}</span>
    </button>
  );
};

export default HeaderCartButton;
