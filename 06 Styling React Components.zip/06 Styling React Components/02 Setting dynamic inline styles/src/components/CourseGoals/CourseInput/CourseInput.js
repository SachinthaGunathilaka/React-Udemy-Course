import React, { useState } from 'react';

import Button from '../../UI/Button/Button';
import './CourseInput.css';

const CourseInput = props => {
  const [enteredValue, setEnteredValue] = useState('');

  // isValid state
  const [isValid, setIsValid] = useState(true);

  const goalInputChangeHandler = event => {
    // If input is valid
    if (event.target.value.trim().length > 0) {
      setIsValid(true); // set isValid to true
    }
    setEnteredValue(event.target.value);
  };

  const formSubmitHandler = event => {
    event.preventDefault();

    // If input is not valid
    if (enteredValue.trim().length === 0) {
      setIsValid(false); // set isValid to false
      return;
    }
    props.onAddGoal(enteredValue);
  };

  return (
    <form onSubmit={formSubmitHandler}>
      <div className="form-control">
        {/* Adding conditional inline css (Inline css has the highest priority than the other styles)*/}
        <label style={{ color: !isValid ? 'red' : 'black' }}>Course Goal</label>
        <input
            {/* Adding conditional inline css (Inline css has the highest priority than the other styles)*/}
            style={{
            borderColor: !isValid ? 'red' : '#ccc',
            background: !isValid ? 'salmon' : 'transparent'
          }}
          type="text"
          onChange={goalInputChangeHandler}
        />
      </div>
      <Button type="submit">Add Goal</Button>
    </form>
  );
};

export default CourseInput;
