// In styled, we can get all html elements
import styled from 'styled-components';

// A button named Button with some styles
// `` is used to write styles
const Button = styled.button`
  font: inherit;
  padding: 0.5rem 1.5rem;
  border: 1px solid #8b005d;
  color: white;
  background: #8b005d;
  box-shadow: 0 0 4px rgba(0, 0, 0, 0.26);
  cursor: pointer;

  // Previously we use .classname : focus (In here no need the class name, only use &)
  // focus => When select (If element is a button we can use tab to select it)
  &:focus {
    outline: none;
  }

  // focus => When go on the object (like click)
  &:hover,
  
  // when it is activated (like click)
  &:active {
    background: #ac0e77;
    border-color: #ac0e77;
    box-shadow: 0 0 8px rgba(0, 0, 0, 0.26);
  }
`;

export default Button;
