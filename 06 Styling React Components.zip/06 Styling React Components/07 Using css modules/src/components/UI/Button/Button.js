/*
  First need to change the css file name(Extension should be .module.css)
  Css file content not need to change (Same as before)
  All the classnames are changed by react, as they are unique
 */
import React from 'react';

// Import styles from that module (styles => can be any name)
import styles from './Button.module.css';

const Button = props => {
  return (
                              // Set class name (button is the class name)
    <button type={props.type} className={styles.button} onClick={props.onClick}>
      {props.children}
    </button>
  );
};

export default Button;
