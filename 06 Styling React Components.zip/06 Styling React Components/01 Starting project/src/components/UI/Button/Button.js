import React from 'react';

import './Button.css';


const Button = props => {
  return (
    // type => taken from the prop
    // no need to send onClick as a prop (Because type is submit, It will auto get the onSubmit())
    <button type={props.type} className="button" onClick={props.onClick}>
      {props.children}
    </button>
  );
};

export default Button;
