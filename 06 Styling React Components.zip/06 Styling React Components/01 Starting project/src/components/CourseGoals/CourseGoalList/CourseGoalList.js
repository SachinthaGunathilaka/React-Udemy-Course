import React from 'react';

import CourseGoalItem from '../CourseGoalItem/CourseGoalItem';
import './CourseGoalList.css';

const CourseGoalList = props => {
  // Unordered list of CourseGoalItem
  return (
    <ul className="goal-list">
      {props.items.map(goal => (
          // Separate CourseGoalItem for each goal
        <CourseGoalItem
          key={goal.id}

          {/* Id is useful when deleting*/}
          id={goal.id}

          {/* Forward function*/}
          onDelete={props.onDeleteItem}
        >
          {/* Children prop*/}
          {goal.text} /
        </CourseGoalItem>
      ))}
    </ul>
  );
};

export default CourseGoalList;
