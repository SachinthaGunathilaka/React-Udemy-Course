import React from 'react';

import './CourseGoalItem.css';

const CourseGoalItem = props => {


  const deleteHandler = () => {
    props.onDelete(props.id); // call function in the prop with the id
  };

  return (
      // call deleteHandler() when clicking
    <li className="goal-item" onClick={deleteHandler}>
      {/* Children prop will be display as a list item */}
      {props.children}
    </li>
  );
};

export default CourseGoalItem;
