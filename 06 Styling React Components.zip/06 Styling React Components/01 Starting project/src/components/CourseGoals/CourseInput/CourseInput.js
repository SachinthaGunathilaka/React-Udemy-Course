import React, { useState } from 'react';

// Import our Button
import Button from '../../UI/Button/Button';
import './CourseInput.css';

const CourseInput = props => {
  const [enteredValue, setEnteredValue] = useState('');

  // onchange function
  const goalInputChangeHandler = event => {
    setEnteredValue(event.target.value); // set state
  };

  // call when form submitting
  const formSubmitHandler = event => {
    event.preventDefault();
    props.onAddGoal(enteredValue); // call the function in the props with the input value
  };

  return (
    <form onSubmit={formSubmitHandler}>
      <div className="form-control">
        <label>Course Goal</label>
        <input type="text" onChange={goalInputChangeHandler} />
      </div>
      {/* Button is user defined Component, type is a prop*/}
      <Button type="submit">Add Goal</Button>
    </form>
  );
};

export default CourseInput;

// No 2 way binding (Cannot clear input after submitting)