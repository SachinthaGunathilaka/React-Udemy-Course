// Check App.js, CourseGoalList.js, CourseGoalItem.js, CourseInput.js, Button.js

import React, { useState } from 'react';

import CourseGoalList from './components/CourseGoals/CourseGoalList/CourseGoalList';
import CourseInput from './components/CourseGoals/CourseInput/CourseInput';
import './App.css';

const App = () => {
  // State (Array of objects)
  const [courseGoals, setCourseGoals] = useState([
    { text: 'Do all exercises!', id: 'g1' },
    { text: 'Finish the course!', id: 'g2' }
  ]);

  // Passing function (Get data from child => enteredText )
  const addGoalHandler = enteredText => {
    setCourseGoals(prevGoals => {
      const updatedGoals = [...prevGoals]; // copy previous array
      // unshift => add new element to start of the array
      updatedGoals.unshift({ text: enteredText, id: Math.random().toString() });
      return updatedGoals;
    });
  };

  // Passing function (This takes goalId from the child)
  const deleteItemHandler = goalId => {
    setCourseGoals(prevGoals => {
      // Remove deleting goal
      const updatedGoals = prevGoals.filter(goal => goal.id !== goalId);
      return updatedGoals;
    });
  };

  // Initialize content
  let content = (
    //  Use inline style
    <p style={{ textAlign: 'center' }}>No goals found. Maybe add one?</p>
  );

  // Set content
  if (courseGoals.length > 0) {
    // CourseGoalList Component (Pass courseGoals and function)
    content = (
      <CourseGoalList items={courseGoals} onDeleteItem={deleteItemHandler} />
    );
  }

  return (
    <div>
      <section id="goal-form">
        {/* CourseInput Component (Passing function) */}
        <CourseInput onAddGoal={addGoalHandler} />
      </section>
      <section id="goals">
        {/* Content */}
        {content}
      </section>
    </div>
  );
};

export default App;
