import React, { useState } from 'react';

import ExpenseItem from './ExpenseItem';
import Card from '../UI/Card';
import ExpensesFilter from './ExpensesFilter';
import './Expenses.css';

const Expenses = (props) => {
  // State                              Default value is 2020 (To appear this value in the dropdown we need to use 2 way binding)
  const [filteredYear, setFilteredYear] = useState('2020');

  // Passing function
  const filterChangeHandler = selectedYear => {
    // Set State with incoming value from child
    setFilteredYear(selectedYear);
  };

  return (
    <div>
      <Card className='expenses'>
        {/* Expenses Filter component, pass function as a prop*/}
        <ExpensesFilter selected={filteredYear} onChangeFilter={filterChangeHandler} />
        {/* selected hold the selected year (For 2 way binding)*/}
        <ExpenseItem
          title={props.items[0].title}
          amount={props.items[0].amount}
          date={props.items[0].date}
        />
        <ExpenseItem
          title={props.items[1].title}
          amount={props.items[1].amount}
          date={props.items[1].date}
        />
        <ExpenseItem
          title={props.items[2].title}
          amount={props.items[2].amount}
          date={props.items[2].date}
        />
        <ExpenseItem
          title={props.items[3].title}
          amount={props.items[3].amount}
          date={props.items[3].date}
        />
      </Card>
    </div>
  );
};

export default Expenses;
