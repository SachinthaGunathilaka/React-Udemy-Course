import React from 'react'; // No need this, This will added automatically

import ExpenseForm from './ExpenseForm';
import './NewExpense.css';

const NewExpense = () => {
  return (
    <div className='new-expense'>
      {/*  Expense Form Component*/}
      <ExpenseForm />
    </div>
  );
};

export default NewExpense;
