// React is default export
// useState is another export (not a default)
import React, { useState } from 'react';

import ExpenseDate from './ExpenseDate';
import Card from '../UI/Card';
import './ExpenseItem.css';

// The component will evaluated initially and when state is changed. (View changes when state is updated.)
// If regular variables (not state) changed, component will not be evaluated.
const ExpenseItem = (props) => {
  /*
    useState() is a react hook. It takes initial value as the argument.
    It returns array of 2 elements.(Name of the state variable, Function to update that state variable).
    In here we use array destructuring.
  */
  const [title, setTitle] = useState(props.title);
  console.log('ExpenseItem evaluated by React');

  // Function attach to Event Listener
  const clickHandler = () => {
    // Update title in the state. (It will also render the the component again)
    setTitle('Updated!');
    console.log(title);
  };

  return (
    <Card className='expense-item'>
      <ExpenseDate date={props.date} />
      <div className='expense-item__description'>
        <h2>{title}</h2>
        <div className='expense-item__price'>${props.amount}</div>
      </div>
      {/*
        Add event listener (on + Event)
        No parenthesis (Only need to point to the function. Not executing)
      */}
      <button onClick={clickHandler}>Change Title</button>
    </Card>
  );
}

export default ExpenseItem;
