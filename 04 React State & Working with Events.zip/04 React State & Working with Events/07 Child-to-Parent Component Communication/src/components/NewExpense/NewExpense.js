import React from 'react';

import ExpenseForm from './ExpenseForm';
import './NewExpense.css';

const NewExpense = (props) => {

  // Passing function (enteredExpenseData is the data pass from child component)
  const saveExpenseDataHandler = (enteredExpenseData) => {
    // Add id to the expenseData object
    const expenseData = {
      ...enteredExpenseData,
      id: Math.random().toString()
    };
    // Call the function in the props with expenseData (send data to the parent component)
    props.onAddExpense(expenseData);
  };

  return (
    <div className='new-expense'>
      {/* Pass function as a prop */}
      <ExpenseForm onSaveExpenseData={saveExpenseDataHandler} />
    </div>
  );
};

export default NewExpense;
