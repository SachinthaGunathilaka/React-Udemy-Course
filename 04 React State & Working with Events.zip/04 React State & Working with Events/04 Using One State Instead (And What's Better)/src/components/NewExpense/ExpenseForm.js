import './ExpenseForm.css';

const ExpenseForm = () => {
  // One state for all state variables
  const [userInput, setUserInput] = useState({
    enteredTitle: '',
    enteredAmount: '',
    enteredDate: '',
  });

  const titleChangeHandler = (event) => {
    // This way is not the best way
    setUserInput({
      ...userInput, // keep other variables as it is
      enteredTitle: event.target.value, // Set new value
    });

    // This is the best way
    /*
        // Pass Arrow functions which takes prevState as the argument
        setUserInput((prevState) => {
          return { ...prevState, enteredTitle: event.target.value }; // return object
        });
     */
  };

  const amountChangeHandler = (event) => {
    setUserInput({
      ...userInput,
      enteredAmount: event.target.value,
    });
  };

  const dateChangeHandler = (event) => {
    setUserInput({
      ...userInput,
      enteredDate: event.target.value,
    });
  };

  return (
      <form>
        <div className='new-expense__controls'>
          <div className='new-expense__control'>
            <label>Title</label>
            <input type='text' onChange={titleChangeHandler} />
          </div>
          <div className='new-expense__control'>
            <label>Amount</label>
            <input
                type='number'
                min='0.01'
                step='0.01'
                onChange={amountChangeHandler}
            />
          </div>
          <div className='new-expense__control'>
            <label>Date</label>
            <input
                type='date'
                min='2019-01-01'
                max='2022-12-31'
                onChange={dateChangeHandler}
            />
          </div>
        </div>
        <div className='new-expense__actions'>
          <button type='submit'>Add Expense</button>
        </div>
      </form>
  );
};

export default ExpenseForm;
