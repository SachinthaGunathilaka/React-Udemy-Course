/*
  If we reload a page or manually go to some URL, all the states in the react will be removed.
  So we will lose the token also. To overcome that we can store it in the browser.
*/

import React, { useState } from "react";

const AuthContext = React.createContext({
  token: "",
  isLoggedIn: false,
  login: (token) => {},
  logout: () => {},
});

export const AuthContextProvider = (props) => {
  // Get token from the browser local storage (This will run when this component start and re-evaluate)
  const initialToken = localStorage.getItem("token");

  // use that initialToken to initialize token state
  const [token, setToken] = useState(initialToken);

  const userIsLoggedIn = !!token;

  const loginHandler = (token) => {
    setToken(token);
    // store token in the browser
    localStorage.setItem("token", token);
  };

  const logoutHandler = () => {
    setToken(null);
    // remove token from the browser
    localStorage.removeItem("token");
  };

  /*
    The problem in this is, token will not be expired
   */
  const contextValue = {
    token: token,
    isLoggedIn: userIsLoggedIn,
    login: loginHandler,
    logout: logoutHandler,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {props.children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
