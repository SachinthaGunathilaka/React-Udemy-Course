// Check App.js, auth-context.js

import { useContext } from "react";
import { Switch, Route, Redirect } from "react-router-dom";

import Layout from "./components/Layout/Layout";
import UserProfile from "./components/Profile/UserProfile";
import AuthPage from "./pages/AuthPage";
import HomePage from "./pages/HomePage";
import AuthContext from "./store/auth-context";

function App() {
  // Initialize context
  const authCtx = useContext(AuthContext);

  return (
    <Layout>
      <Switch>
        <Route path="/" exact>
          <HomePage />
        </Route>

        {/* Can go to AuthPage If only user not logged in */}
        {!authCtx.isLoggedIn && (
          <Route path="/auth">
            <AuthPage />
          </Route>
        )}

        {/* For /profile path */}
        <Route path="/profile">
          {/* If user logged in go to UserProfile comp */}
          {authCtx.isLoggedIn && <UserProfile />}
          {/* If user not logged in go to AuthPage */}
          {!authCtx.isLoggedIn && <Redirect to="/auth" />}
        </Route>

        {/* For any other router */}
        <Route path="*">
          <Redirect to="/" />
        </Route>
      </Switch>
    </Layout>
  );
}

export default App;
