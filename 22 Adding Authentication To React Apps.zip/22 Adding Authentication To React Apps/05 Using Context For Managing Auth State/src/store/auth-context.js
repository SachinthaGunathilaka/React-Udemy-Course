import React, { useState } from "react";

// Define context
const AuthContext = React.createContext({
  // default values
  token: "",
  isLoggedIn: false,
  // function definitions
  login: (token) => {},
  logout: () => {},
});

// AuthContext Provider (Export it by name)
export const AuthContextProvider = (props) => {
  // state for token
  const [token, setToken] = useState(null);

  // isLoggedin boolean value using token (!! will return true if token is not empty)
  const userIsLoggedIn = !!token;

  // When login
  const loginHandler = (token) => {
    // set incoming token to state
    setToken(token);
  };

  // when log out
  const logoutHandler = () => {
    // clear the token
    setToken(null);
  };

  // Passing values for context
  const contextValue = {
    token: token, // state
    isLoggedIn: userIsLoggedIn, // generated value
    // funcitons
    login: loginHandler,
    logout: logoutHandler,
  };

  return (
    //  Context provider (Pass values)
    <AuthContext.Provider value={contextValue}>
      {props.children}
    </AuthContext.Provider>
  );
};

// Default export is context
export default AuthContext;
