import ReactDOM from "react-dom";
import { BrowserRouter } from "react-router-dom";

import "./index.css";
import App from "./App";

// Export by name AuthContextProvider
import { AuthContextProvider } from "./store/auth-context";

ReactDOM.render(
  // Wrap the App by Context provider
  <AuthContextProvider>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </AuthContextProvider>,
  document.getElementById("root")
);
