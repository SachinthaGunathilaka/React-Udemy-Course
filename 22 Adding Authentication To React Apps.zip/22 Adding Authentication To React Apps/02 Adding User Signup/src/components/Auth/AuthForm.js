import { useState, useRef } from "react";

import classes from "./AuthForm.module.css";

const AuthForm = () => {
  // Refs for inputs
  const emailInputRef = useRef();
  const passwordInputRef = useRef();

  // isLogin state (To identify the login and signup page)
  const [isLogin, setIsLogin] = useState(true);

  // isLogin state toggle
  const switchAuthModeHandler = () => {
    setIsLogin((prevState) => !prevState);
  };

  // When submitting the form
  const submitHandler = (event) => {
    event.preventDefault();

    // Get input values
    const enteredEmail = emailInputRef.current.value;
    const enteredPassword = passwordInputRef.current.value;

    // optional: Add validation

    // For Login page
    if (isLogin) {
      // Not implemented yet
    }
    // For signup page
    else {
      fetch(
        // End point URL (This URL is taken from the documentation)
        "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyBZhsabDexE9BhcJbGxnZ4DiRlrCN9xe24",
        // In the API documentation, it says all the parameters that we need to pass (request should be JSON type)
        {
          method: "POST",
          body: JSON.stringify({
            email: enteredEmail, // email
            password: enteredPassword, // password
            returnSecureToken: true, // When we want to get Token from the API (For secure, we should get this token)
            // If we use this as true, when every time we login or signup, it will return a token. That token can be used as a validation for every request
          }),
          headers: {
            "Content-Type": "application/json", // JSON type
          },
        }
      ).then((res) => {
        // If the response is ok
        if (res.ok) {
          // ...
        }
        // If there is an error
        else {
          // convert response to js object
          return res.json().then((data) => {
            // show an error modal
            console.log(data);
          });
        }
      });
    }
  };

  return (
    <section className={classes.auth}>
      {/* Dynamic page title */}
      <h1>{isLogin ? "Login" : "Sign Up"}</h1>

      {/* Form - when submitting submitHandler will execute */}
      <form onSubmit={submitHandler}>
        {/* Email */}
        <div className={classes.control}>
          <label htmlFor="email">Your Email</label>
          <input type="email" id="email" required ref={emailInputRef} />
        </div>
        {/* Password */}
        <div className={classes.control}>
          <label htmlFor="password">Your Password</label>
          <input
            type="password"
            id="password"
            required
            ref={passwordInputRef}
          />
        </div>
        {/* Button */}
        <div className={classes.actions}>
          {/* Dynamic button name*/}
          <button>{isLogin ? "Login" : "Create Account"}</button>

          {/* Button for switch between login and sign up pages */}
          <button
            type="button"
            className={classes.toggle}
            onClick={switchAuthModeHandler} // Handler
          >
            {/* Dynamic button name*/}
            {isLogin ? "Create new account" : "Login with existing account"}
          </button>
        </div>
      </form>
    </section>
  );
};

export default AuthForm;
