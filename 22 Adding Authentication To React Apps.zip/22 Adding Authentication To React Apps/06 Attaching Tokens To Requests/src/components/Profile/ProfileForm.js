import { useRef, useContext } from "react";

import AuthContext from "../../store/auth-context";
import classes from "./ProfileForm.module.css";

const ProfileForm = () => {
  // Ref for new password input
  const newPasswordInputRef = useRef();
  // Initialize context
  const authCtx = useContext(AuthContext);

  const submitHandler = (event) => {
    event.preventDefault();

    // get input value for new password
    const enteredNewPassword = newPasswordInputRef.current.value;

    // add validation

    // send request to update password
    fetch(
      "https://identitytoolkit.googleapis.com/v1/accounts:update?key=AIzaSyBZhsabDexE9BhcJbGxnZ4DiRlrCN9xe24",
      {
        method: "POST",
        body: JSON.stringify({
          idToken: authCtx.token, // This req should contains the token
          password: enteredNewPassword, // new password
          returnSecureToken: false, // If this is true it will send new token
        }),
        headers: {
          "Content-Type": "application/json",
        },
      }
    ).then((res) => {
      // assumption: Always succeeds!
    });
  };

  return (
    <form className={classes.form} onSubmit={submitHandler}>
      {/* New password input */}
      <div className={classes.control}>
        <label htmlFor="new-password">New Password</label>
        <input
          type="password"
          id="new-password"
          minLength="7"
          ref={newPasswordInputRef}
        />
      </div>
      <div className={classes.action}>
        <button>Change Password</button>
      </div>
    </form>
  );
};

export default ProfileForm;
