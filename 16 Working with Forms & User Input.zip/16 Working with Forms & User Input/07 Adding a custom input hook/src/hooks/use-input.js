import { useState } from "react";

// custom hook
const useInput = (validateValue) => {
  // State for value and isTouched
  const [enteredValue, setEnteredValue] = useState("");
  const [isTouched, setIsTouched] = useState(false);

  // Use function in the argument to validate
  const valueIsValid = validateValue(enteredValue); // To prevent submit
  const hasError = !valueIsValid && isTouched; // To display errors

  // when changing input
  const valueChangeHandler = (event) => {
    setEnteredValue(event.target.value);
  };

  // After lose focus
  const inputBlurHandler = (event) => {
    setIsTouched(true);
  };

  // Reset function
  const reset = () => {
    setEnteredValue("");
    setIsTouched(false);
  };

  // return state, values and funcs
  return {
    value: enteredValue, // alias (for naming)
    isValid: valueIsValid,
    hasError,
    valueChangeHandler,
    inputBlurHandler,
    reset,
  };
};

export default useInput;
