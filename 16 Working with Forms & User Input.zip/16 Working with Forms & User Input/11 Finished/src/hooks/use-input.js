// Use useReducer instead of useState

import { useReducer } from "react";

// Initial state
const initialInputState = {
  value: "",
  isTouched: false,
};

// Reducer function
const inputStateReducer = (state, action) => {
  // For input changes
  if (action.type === "INPUT") {
    // set value as the input, keep isTouched as it is
    return { value: action.value, isTouched: state.isTouched };
  }
  // For loose focus
  if (action.type === "BLUR") {
    // set isTouched as true, keep value as it is
    return { isTouched: true, value: state.value };
  }

  // After submitting
  if (action.type === "RESET") {
    // reset values
    return { isTouched: false, value: "" };
  }
  return inputStateReducer;
};

const useInput = (validateValue) => {
  // Initiate useReducer
  const [inputState, dispatch] = useReducer(
    inputStateReducer,
    initialInputState // Initial state
  );

  const valueIsValid = validateValue(inputState.value);
  const hasError = !valueIsValid && inputState.isTouched;

  const valueChangeHandler = (event) => {
    dispatch({ type: "INPUT", value: event.target.value }); // call reducer func
  };

  const inputBlurHandler = (event) => {
    dispatch({ type: "BLUR" }); // call reducer func
  };

  const reset = () => {
    dispatch({ type: "RESET" }); // call reducer func
  };

  return {
    value: inputState.value, // value in the state
    isValid: valueIsValid,
    hasError,
    valueChangeHandler,
    inputBlurHandler,
    reset,
  };
};

export default useInput;
