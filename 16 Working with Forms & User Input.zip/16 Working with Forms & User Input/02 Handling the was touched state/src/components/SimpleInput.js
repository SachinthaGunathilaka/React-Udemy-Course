import { useEffect, useRef, useState } from "react";

/*
  The error will display after submit form and the error will disappear after submit correct value
 */
const SimpleInput = (props) => {
  const nameInputRef = useRef();

  // State for name and validation
  const [enteredName, setEnteredName] = useState("");
  const [enteredNameIsValid, setEnteredNameIsValid] = useState(false);
  const [enteredNameTouched, setEnteredNameTouched] = useState(false);

  const nameInputChangeHandler = (event) => {
    setEnteredName(event.target.value);
  };

  const formSubmissionHandler = (event) => {
    event.preventDefault();

    // Set enteredNameTouched to true
    setEnteredNameTouched(true);

    // Check for non empty value
    if (enteredName.trim() === "") {
      setEnteredNameIsValid(false);
      return;
    }

    // Set as valid value
    setEnteredNameIsValid(true);

    console.log(enteredName);

    const enteredValue = nameInputRef.current.value;
    console.log(enteredValue);

    // nameInputRef.current.value = ''; => NOT IDEAL, DON'T MANIPULATE THE DOM
    setEnteredName("");
  };

  // check whether the input field is touched and is valid
  const nameInputIsInvalid = !enteredNameIsValid && enteredNameTouched;

  // Dynamically set classes
  const nameInputClasses = nameInputIsInvalid
    ? "form-control invalid"
    : "form-control";

  return (
    <form onSubmit={formSubmissionHandler}>
      {/* Dynamically generated classes */}
      <div className={nameInputClasses}>
        <label htmlFor="name">Your Name</label>
        <input
          ref={nameInputRef}
          type="text"
          id="name"
          onChange={nameInputChangeHandler}
          value={enteredName}
        />
        {/* Display errors dynamically */}
        {nameInputIsInvalid && (
          <p className="error-text">Name must not be empty.</p>
        )}
      </div>
      <div className="form-actions">
        <button>Submit</button>
      </div>
    </form>
  );
};

export default SimpleInput;
