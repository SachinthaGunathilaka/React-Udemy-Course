import { useState } from "react";

const SimpleInput = (props) => {
  // State for name and isTouched
  const [enteredName, setEnteredName] = useState("");
  const [enteredNameTouched, setEnteredNameTouched] = useState(false);

  /*
   Check for validity (When input changes, this comp will be re evaluated.)
   Therefore validity also check again.

   enteredNameIsValid => prevent submitting form
   nameInputIsInvalid => for displaying errors
   */
  const enteredNameIsValid = enteredName.trim() !== "";
  const nameInputIsInvalid = !enteredNameIsValid && enteredNameTouched;

  const nameInputChangeHandler = (event) => {
    setEnteredName(event.target.value);
  };

  const nameInputBlurHandler = (event) => {
    // when lost focus
    setEnteredNameTouched(true);
  };

  /*
    Note : Steps of executing this func
    1) Func will be executed line by line
    2) State updating funcs will send to batch.
    3) Function execution and state updating happen simultaneously.  (Updated values of this states cannot be access in here)
    4) After executing this func component re evaluation happens.
   */
  const formSubmissionHandler = (event) => {
    event.preventDefault();

    // This is needed when click submit without focusing input.
    setEnteredNameTouched(true);

    // Only submit if valid
    if (!enteredNameIsValid) {
      return;
    }

    console.log(enteredName);

    /*
      set setEnteredNameTouched as false. After submitting reset values
    */
    setEnteredName("");
    setEnteredNameTouched(false);
  };

  // Dynamically generate classes
  const nameInputClasses = nameInputIsInvalid
    ? "form-control invalid"
    : "form-control";

  return (
    <form onSubmit={formSubmissionHandler}>
      <div className={nameInputClasses}>
        <label htmlFor="name">Your Name</label>
        <input
          type="text"
          id="name"
          onChange={nameInputChangeHandler}
          onBlur={nameInputBlurHandler}
          value={enteredName}
        />
        {/* Show error dynamically */}
        {nameInputIsInvalid && (
          <p className="error-text">Name must not be empty.</p>
        )}
      </div>
      <div className="form-actions">
        <button>Submit</button>
      </div>
    </form>
  );
};

export default SimpleInput;
