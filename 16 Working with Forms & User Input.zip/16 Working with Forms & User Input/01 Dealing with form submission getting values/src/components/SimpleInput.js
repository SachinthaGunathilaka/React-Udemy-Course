import { useRef, useState } from "react";

const SimpleInput = (props) => {
  // Use Ref initiate
  const nameInputRef = useRef();
  // State for name
  const [enteredName, setEnteredName] = useState("");

  // When name changes
  const nameInputChangeHandler = (event) => {
    setEnteredName(event.target.value);
  };

  // When submitting
  const formSubmissionHandler = (event) => {
    event.preventDefault();

    // using state
    console.log(enteredName);

    // using refs
    const enteredValue = nameInputRef.current.value;
    console.log(enteredValue);

    // nameInputRef.current.value = ''; => NOT IDEAL, DON'T MANIPULATE THE DOM
    setEnteredName(""); // reset state value
  };

  return (
    <form onSubmit={formSubmissionHandler}>
      <div className="form-control">
        <label htmlFor="name">Your Name</label>
        <input
          ref={nameInputRef} // ref
          type="text"
          id="name"
          onChange={nameInputChangeHandler}
          value={enteredName} // 2 way binding
        />
      </div>
      <div className="form-actions">
        <button>Submit</button>
      </div>
    </form>
  );
};

export default SimpleInput;
