// Check App.js, DemoOutput.js

/*
    When App comp re-evaluating all the child comps will be re-evaluated.
    By using react.memo inside child comps, child comps will be only re-evaluated when only passing props changed.
    That is done by comparing previous and current prop values.

    (Inside child comps, if state or context changes, it will be re-evaluated. Here we consider the situation when parent
     comp re evaluating, child comps also re evaluating)
 */
import React, { useState } from "react";

import Button from "./components/UI/Button/Button";
import DemoOutput from "./components/Demo/DemoOutput";
import "./App.css";

function App() {
  const [showParagraph, setShowParagraph] = useState(false);

  console.log("APP RUNNING");

  const toggleParagraphHandler = () => {
    setShowParagraph((prevShowParagraph) => !prevShowParagraph);
  };

  return (
    <div className="app">
      <h1>Hi there!</h1>
      <DemoOutput show={false} />
      <Button onClick={toggleParagraphHandler}>Toggle Paragraph!</Button>
    </div>
  );
}

export default App;

// When App re-evaluates DemoOutput will not be re-evaluated. Because incoming props are not changing.
/*
    If we use memo inside Button comp, Button will always re evaluate when App re evaluating.
    Because we pass function as a prop. When App is re evaluating, all the functions inside App also re creating.
    Therefore previous toggleParagraphHandler and current toggleParagraphHandler are not same(Pointers).
*/
