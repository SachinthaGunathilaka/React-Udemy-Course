import React from "react";

import MyParagraph from "./MyParagraph";

const DemoOutput = (props) => {
  console.log("DemoOutput RUNNING");
  return <MyParagraph>{props.show ? "This is new!" : ""}</MyParagraph>;
};

// Due to App comp re-evaluated => DemoOutput will re evaluated only if incoming props changed.
export default React.memo(DemoOutput);
