// Check App.js, DemoList.js

import React, { useState, useCallback, useMemo } from "react";

import "./App.css";
import DemoList from "./components/Demo/DemoList";
import Button from "./components/UI/Button/Button";

function App() {
  const [listTitle, setListTitle] = useState("My List");

  const changeTitleHandler = useCallback(() => {
    setListTitle("New Title");
  }, []);

  /*
      Like functions objects, array also re create when component re evaluated. So cannot compare them(Always false)
      So we store items also using useMemo. No dependencies(never changes)
     */
  const listItems = useMemo(() => [5, 3, 1, 10, 9], []);

  return (
    <div className="app">
      {/* Pass list items */}
      <DemoList title={listTitle} useMemo={listItems} />
      <Button onClick={changeTitleHandler}>Change List Title</Button>
    </div>
  );
}

export default App;
