/*
    A component will be re-evaluated
        - If state changes
        - If incoming props changes
        - If context changes (When we use context inside the component)
 */

import React, { useState } from "react";

import Button from "./components/UI/Button/Button";
import "./App.css";

function App() {
  // state for paragraph showing
  const [showParagraph, setShowParagraph] = useState(false);

  console.log("APP RUNNING");

  // paragraph show state handler
  const toggleParagraphHandler = () => {
    setShowParagraph((prevShowParagraph) => !prevShowParagraph);
  };

  return (
    // When button is clicked paragraph will show or hide
    <div className="app">
      <h1>Hi there!</h1>
      {showParagraph && <p>This is new!</p>}
      <Button onClick={toggleParagraphHandler}>Toggle Paragraph!</Button>
    </div>
  );
}

export default App;
