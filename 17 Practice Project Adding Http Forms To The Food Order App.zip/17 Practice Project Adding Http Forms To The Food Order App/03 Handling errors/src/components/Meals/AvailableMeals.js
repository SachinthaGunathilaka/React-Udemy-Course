import { useEffect, useState } from "react";

import Card from "../UI/Card";
import MealItem from "./MealItem/MealItem";
import classes from "./AvailableMeals.module.css";

const AvailableMeals = () => {
  // State for meals, isLoading, error
  const [meals, setMeals] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [httpError, setHttpError] = useState();

  const fetchMeals = () => {
    setIsLoading(true); // set isLoading to true

    // send request to API to fetch meals
    fetch("https://react-http-6b4a6.firebaseio.com/meals.json")
      .then((response) => {
        // Check for error
        if (!response.ok) {
          throw new Error("Something went wrong!");
        }
        return response.json();
      })
      .then((responseData) => {
        // generate meals to store
        const loadedMeals = [];
        for (const key in responseData) {
          loadedMeals.push({
            id: key,
            name: responseData[key].name,
            description: responseData[key].description,
            price: responseData[key].price,
          });
        }
        // add meals to state
        setMeals(loadedMeals);
        // setIsLoading to false
        setIsLoading(false);
      })
      .catch((error) => {
        // Catching errors
        setIsLoading(false); // set isLoading to false
        setHttpError(error.message); // set error
      });
  };

  // fetch meals at the start
  useEffect(() => {
    fetchMeals();
  }, []);

  // Display isLoading text when loading
  if (isLoading) {
    return (
      <section className={classes.MealsLoading}>
        <p>Loading...</p>
      </section>
    );
  }

  // Display Error text when there is an error
  if (httpError) {
    return (
      <section className={classes.MealsError}>
        <p>{httpError}</p>
      </section>
    );
  }

  // List of meals
  const mealsList = meals.map((meal) => (
    <MealItem
      key={meal.id}
      id={meal.id}
      name={meal.name}
      description={meal.description}
      price={meal.price}
    />
  ));

  return (
    <section className={classes.meals}>
      <Card>
        {/* If there is no errors and no isLoading display meals */}
        <ul>{mealsList}</ul>
      </Card>
    </section>
  );
};

export default AvailableMeals;
