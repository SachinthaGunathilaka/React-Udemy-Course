import { Route } from "react-router-dom";

const Welcome = () => {
  return (
    <section>
      <h1>The Welcome Page</h1>
      {/* 
        If URL is /welcome => Only Welcome comp will display without following paragraph 
        If the URL is /welcome/new-user => Welcome comp with following paragraph will display.

      */}
      <Route path="/welcome/new-user">
        <p>Welcome, new user!</p>
      </Route>
    </section>
  );
};

export default Welcome;

// We can use Router in any component (Not just in one place)
