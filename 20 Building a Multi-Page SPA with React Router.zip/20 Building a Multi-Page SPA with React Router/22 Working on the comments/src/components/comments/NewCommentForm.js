import { useRef, useEffect } from "react";

import useHttp from "../../hooks/use-http";
import { addComment } from "../../lib/api";
import LoadingSpinner from "../UI/LoadingSpinner";
import classes from "./NewCommentForm.module.css";

const NewCommentForm = (props) => {
  const commentTextRef = useRef();

  // Initiate custom hook with addComment function
  const { sendRequest, status, error } = useHttp(addComment);

  const { onAddedComment } = props;

  // This will execute when status or error changed
  useEffect(() => {
    // If the status is completed and no error
    if (status === "completed" && !error) {
      // Execute function in the prop
      onAddedComment();
    }
  }, [status, error, onAddedComment]);
  // add all the dependencies (Need set onAddedComment inside comments as a callback)

  // Submit function
  const submitFormHandler = (event) => {
    event.preventDefault();

    // get input value
    const enteredText = commentTextRef.current.value;

    // execute sendRequest function in the hook
    // Pass relevant arguments
    sendRequest({ commentData: { text: enteredText }, quoteId: props.quoteId });
  };

  return (
    // When submitting submitFormHandler will be executed
    <form className={classes.form} onSubmit={submitFormHandler}>
      {/* If the state is pending show loading spinner (On the form) */}
      {status === "pending" && (
        <div className="centered">
          <LoadingSpinner />
        </div>
      )}
      <div className={classes.control} onSubmit={submitFormHandler}>
        <label htmlFor="comment">Your Comment</label>
        <textarea id="comment" rows="5" ref={commentTextRef}></textarea>
      </div>
      <div className={classes.actions}>
        <button className="btn">Add Comment</button>
      </div>
    </form>
  );
};

export default NewCommentForm;
