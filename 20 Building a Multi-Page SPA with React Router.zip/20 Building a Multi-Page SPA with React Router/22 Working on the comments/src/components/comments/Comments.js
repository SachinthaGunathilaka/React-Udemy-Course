import { useState, useEffect, useCallback } from "react";
import { useParams } from "react-router-dom";

import classes from "./Comments.module.css";
import NewCommentForm from "./NewCommentForm";
import useHttp from "../../hooks/use-http";
import { getAllComments } from "../../lib/api";
import LoadingSpinner from "../UI/LoadingSpinner";
import CommentsList from "./CommentsList";

const Comments = () => {
  const [isAddingComment, setIsAddingComment] = useState(false);
  const params = useParams();

  // Extract quoteId from the params
  const { quoteId } = params;

  // Initiate hook with getAllComments function
  const { sendRequest, status, data: loadedComments } = useHttp(getAllComments);

  // This will execute initially
  useEffect(() => {
    // Execute sendRequest func in the hook
    sendRequest(quoteId);
  }, [quoteId, sendRequest]);
  // add dependencies as a good practice

  // When click on the comment adding button
  const startAddCommentHandler = () => {
    setIsAddingComment(true);
  };

  // passing function (set addedCommentHandler as a callback, because we use this as a dependency inside NewCommentForm.js)
  const addedCommentHandler = useCallback(() => {
    /*
      after adding new comment, send new request to fetch all comments
      Therefore the reducer state will be changed. So this comp will be re-evaluated.
      Actually we dont need to do that. We can just reload the page by redirecting
     */

    sendRequest(quoteId);
  }, [sendRequest, quoteId]);
  // add dependencies for callback

  let comments;

  // While fetching comments from the db
  if (status === "pending") {
    comments = (
      <div className="centered">
        <LoadingSpinner />
      </div>
    );
  }

  // After loading comments successfully
  if (status === "completed" && loadedComments && loadedComments.length > 0) {
    // CommentsList component (Pass loaded comments as a prop)
    comments = <CommentsList comments={loadedComments} />;
  }

  // If there is any error while fetching comments
  if (
    status === "completed" &&
    (!loadedComments || loadedComments.length === 0)
  ) {
    comments = <p className="centered">No comments were added yet!</p>;
  }

  return (
    <section className={classes.comments}>
      <h2>User Comments</h2>
      {/* Button for adding new comment */}
      {!isAddingComment && (
        <button className="btn" onClick={startAddCommentHandler}>
          Add a Comment
        </button>
      )}

      {/* Form for adding new comment */}
      {isAddingComment && (
        <NewCommentForm
          // pass id of the quote
          quoteId={quoteId}
          onAddedComment={addedCommentHandler} // pass function
        />
      )}

      {/* Comments => This will be a loading spinner or text or all comments */}
      {comments}
    </section>
  );
};

export default Comments;
