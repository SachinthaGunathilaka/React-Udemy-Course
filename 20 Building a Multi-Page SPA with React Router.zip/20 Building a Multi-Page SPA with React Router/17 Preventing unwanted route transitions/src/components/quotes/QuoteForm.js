/*
  While entering data in the form, If we accidentally click any link all
  the entered data will be lost. So we can add some popup box to confirm before redirecting. 
*/

import { Fragment, useRef, useState } from "react";

// prompt
import { Prompt } from "react-router-dom";

import Card from "../UI/Card";
import LoadingSpinner from "../UI/LoadingSpinner";
import classes from "./QuoteForm.module.css";

const QuoteForm = (props) => {
  // State for isEntering form data
  const [isEntering, setIsEntering] = useState(false);

  const authorInputRef = useRef();
  const textInputRef = useRef();

  function submitFormHandler(event) {
    event.preventDefault();

    const enteredAuthor = authorInputRef.current.value;
    const enteredText = textInputRef.current.value;

    // optional: Could validate here

    props.onAddQuote({ author: enteredAuthor, text: enteredText });
  }

  // Before submit form (When click submit button) set isEntering to False
  const finishEnteringHandler = () => {
    setIsEntering(false);
  };

  // When focus to the form set isEntering to True
  const formFocusedHandler = () => {
    setIsEntering(true);
  };

  return (
    <Fragment>
      {/* Prompt (If we try to go another link and if "when" is true, then prompt will display)*/}
      <Prompt
        {/* When to prompt */}
        when={isEntering}
        {/* Prompting message (It should be a return value of a func) */}
        message={(location) =>
          "Are you sure you want to leave? All your entered data will be lost!"
        }
      />
      <Card>
        <form
          // onFocus method
          onFocus={formFocusedHandler}
          className={classes.form}
          onSubmit={submitFormHandler}
        >
          {props.isLoading && (
            <div className={classes.loading}>
              <LoadingSpinner />
            </div>
          )}

          <div className={classes.control}>
            <label htmlFor="author">Author</label>
            <input type="text" id="author" ref={authorInputRef} />
          </div>
          <div className={classes.control}>
            <label htmlFor="text">Text</label>
            <textarea id="text" rows="5" ref={textInputRef}></textarea>
          </div>
          <div className={classes.actions}>
            {/* When submitting form also, the pop up box will show.
              To overcome that we need to set isEntering to False before submitting.
              We cannot set inside submitFormHandler. Because state updating take sometime.
            */}
            <button onClick={finishEnteringHandler} className="btn">
              Add Quote
            </button>
          </div>
        </form>
      </Card>
    </Fragment>
  );
};

export default QuoteForm;
