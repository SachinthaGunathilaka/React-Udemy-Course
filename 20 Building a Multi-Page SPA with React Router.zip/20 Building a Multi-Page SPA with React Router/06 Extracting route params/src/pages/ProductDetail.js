// useParams hook
import { useParams } from "react-router-dom";

const ProductDetail = () => {
  // Initialize useParams
  const params = useParams();

  // Access params (productId is the param name)
  console.log(params.productId);

  return (
    <section>
      {/* Display param */}
      <p>{params.productId}</p>
    </section>
  );
};

export default ProductDetail;

/*
    If we enter our-domain.com/product-detail/a-book URL =>
        "a book" will be displayed
 */
