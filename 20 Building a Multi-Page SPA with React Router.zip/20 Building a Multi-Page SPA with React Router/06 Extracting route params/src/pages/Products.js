const Products = () => {
  return (
    <section>
      <h1>The Products Page</h1>
      <ul>
        <li>A Book</li>
        <li>A Carpet</li>
        <li>An Online Course</li>
      </ul>
    </section>
  );
};

export default Products;
