import QuoteForm from "../components/quotes/QuoteForm";

const NewQuote = () => {
  // Passing func
  const addQuoteHandler = (quoteData) => {
    // console.log incoming data
    console.log(quoteData);
  };

  // QuoteForm comp
  return <QuoteForm onAddQuote={addQuoteHandler} />;
};

export default NewQuote;
