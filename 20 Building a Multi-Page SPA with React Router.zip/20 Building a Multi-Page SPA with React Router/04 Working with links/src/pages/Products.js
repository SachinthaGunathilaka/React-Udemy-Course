const Products = () => {
  return <h1>The Products Page</h1>;
};

export default Products;