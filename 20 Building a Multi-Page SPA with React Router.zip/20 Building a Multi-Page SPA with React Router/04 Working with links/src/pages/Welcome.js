const Welcome = () => {
  return <h1>The Welcome Page</h1>;
};

export default Welcome;