// Import Link
import { Link } from "react-router-dom";

import classes from "./MainHeader.module.css";

const MainHeader = () => {
  return (
    <header className={classes.header}>
      <nav>
        <ul>
          <li>
            {/*
                <a href={'/welcome'}>Welcome</a>
                If we use anchor tag that also work. 
                But when click on the link, A new request will be send and page will be reloaded. So current state data will
                be lost. We need to prevent default. To overcome that Link can be used. (Link => anchor with prevent default)
                Use "to" instead of "href"
            */}

            <Link to="/welcome">Welcome</Link>
          </li>
          <li>
            <Link to="/products">Products</Link>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default MainHeader;
