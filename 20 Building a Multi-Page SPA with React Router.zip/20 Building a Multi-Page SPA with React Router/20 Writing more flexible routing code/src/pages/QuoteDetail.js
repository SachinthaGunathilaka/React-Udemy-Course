import { Fragment } from "react";

// useRouteMatch hook
import { useParams, Route, Link, useRouteMatch } from "react-router-dom";

import HighlightedQuote from "../components/quotes/HighlightedQuote";
import Comments from "../components/comments/Comments";

const DUMMY_QUOTES = [
  { id: "q1", author: "Max", text: "Learning React is fun!" },
  { id: "q2", author: "Maximilian", text: "Learning React is great!" },
];

const QuoteDetail = () => {
  // Initialize useRouteMatch
  const match = useRouteMatch();
  const params = useParams();
  console.log(match);

  const quote = DUMMY_QUOTES.find((quote) => quote.id === params.quoteId);

  if (!quote) {
    return <p>No quote found!</p>;
  }

  return (
    <Fragment>
      <HighlightedQuote text={quote.text} author={quote.author} />
      {/* match.url => Path defined in Route for QuoteDetail component */}
      <Route path={match.url} exact>
        <div className="centered">
          {/* match.url => /quotes/quoteId */}
          <Link className="btn--flat" to={`${match.url}/comments`}>
            Load Comments
          </Link>
        </div>
      </Route>
      {/* match.url => /quotes/quoteId */}
      <Route path={`${match.url}/comments`}>
        <Comments />
      </Route>
    </Fragment>
  );
};

export default QuoteDetail;

/*
    We cannot use location.pathname here. 
    Because when changing URL from /quotes/quoteId to /quotes/quoteId/comments, location.pathname also changed.
    But match.url not changed.
    
 */
