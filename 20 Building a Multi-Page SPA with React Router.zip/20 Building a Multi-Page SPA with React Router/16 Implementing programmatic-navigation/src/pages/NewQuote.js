// useHistory hook
import { useHistory } from "react-router-dom";

import QuoteForm from "../components/quotes/QuoteForm";

const NewQuote = () => {
  // Instantiate useHistory
  const history = useHistory();

  // When submit new quote this method will be executed.
  const addQuoteHandler = (quoteData) => {
    console.log(quoteData);

    /*
      history.push() => go to /quotes route. (Can go back using back button)
      We can use history.replace() => Same as this but we cannot go back using back button (This is like redirect)
     */
    history.push("/quotes");
  };

  return <QuoteForm onAddQuote={addQuoteHandler} />;
};

export default NewQuote;
