import { Fragment } from "react";

/*
  useHistory => To manage URL (Like redirecting)
  useLocation => To get Information about currently loaded URL
 */
import { useHistory, useLocation } from "react-router-dom";

import QuoteItem from "./QuoteItem";
import classes from "./QuoteList.module.css";

// A function to sort quotes ascending or descending (This func can defined inside QuoteList comp also)
const sortQuotes = (quotes, ascending) => {
  return quotes.sort((quoteA, quoteB) => {
    /*
      Sort Using compare function
      If the return value is negative quoteA is sorted before quoteB
     */
    if (ascending) {
      return quoteA.id > quoteB.id ? 1 : -1;
    } else {
      return quoteA.id < quoteB.id ? 1 : -1;
    }
  });
};

const QuoteList = (props) => {
  // Initialize hooks objects
  const history = useHistory();
  const location = useLocation();
  console.log(location);

  // Extract query parameters object (URLSearchParams is a inbuid method is JS)
  // pass location.search as args
  const queryParams = new URLSearchParams(location.search);

  // Generate isSortingAscending according to the query params ("sort" is the name of the query param)
  const isSortingAscending = queryParams.get("sort") === "asc";

  /*
    Call sortQuotes func and get sorted quotes.
    When sort button clicked, URL will be changed, so the components that relevant to that URL will be reevaluated.
   */
  const sortedQuotes = sortQuotes(props.quotes, isSortingAscending);

  // When sorting button clicked this will be executed
  const changeSortingHandler = () => {
    /*
      Change URL dynamically ( Use "?" before the query param)
      Therefore It will redirect to /quotes (Also it contains some other information)
     */
    history.push("/quotes?sort=" + (isSortingAscending ? "desc" : "asc"));
  };

  return (
    <Fragment>
      <div className={classes.sorting}>
        {/* Sorting button */}
        <button onClick={changeSortingHandler}>
          {/* Dynamic button name */}
          Sort {isSortingAscending ? "Descending" : "Ascending"}
        </button>
      </div>
      <ul className={classes.list}>
        {/* Use sortedQuotes array */}
        {sortedQuotes.map((quote) => (
          <QuoteItem
            key={quote.id}
            id={quote.id}
            author={quote.author}
            text={quote.text}
          />
        ))}
      </ul>
    </Fragment>
  );
};

export default QuoteList;
