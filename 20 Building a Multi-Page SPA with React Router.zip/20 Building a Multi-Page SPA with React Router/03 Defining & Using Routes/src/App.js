// Check App.js, Index.js

// Import Route
import { Route } from "react-router-dom";

import Welcome from "./pages/Welcome";
import Products from "./pages/Products";

function App() {
  return (
    <div>
      {/* our-domain.com/welcome => Show Welcome Component */}
      <Route path="/welcome">
        <Welcome />
      </Route>

      {/*our-domain.com/products => Show Products Component */}
      <Route path="/products">
        <Products />
      </Route>
    </div>
  );
}

export default App;
