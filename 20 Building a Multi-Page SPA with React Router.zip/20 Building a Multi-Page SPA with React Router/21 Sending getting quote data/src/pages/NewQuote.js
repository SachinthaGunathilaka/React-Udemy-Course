import { useEffect } from "react";
import { useHistory } from "react-router-dom";
import QuoteForm from "../components/quotes/QuoteForm";
import useHttp from "../hooks/use-http";
import { addQuote } from "../lib/api";

const NewQuote = () => {
  // initiate custom hook (Point to addQuote func - not executing)
  // Only get state from httpState
  const { sendRequest, status } = useHttp(addQuote);
  const history = useHistory();

  // This will execute when status changes
  // (history will never changed, it is defined because it is used inside - as a good practice )
  useEffect(() => {
    // If the status is completed redirect
    if (status === "completed") {
      history.push("/quotes");
    }
  }, [status, history]);

  const addQuoteHandler = (quoteData) => {
    // call sendRequest with sendRequest => This will execute addQuote function
    // This will update status
    sendRequest(quoteData);
  };

  return (
    // Pass isLoading as a prop (It is taken by comparing status)
    <QuoteForm isLoading={status === "pending"} onAddQuote={addQuoteHandler} />
  );
};

export default NewQuote;
