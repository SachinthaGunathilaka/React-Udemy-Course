import { useEffect } from "react";

import QuoteList from "../components/quotes/QuoteList";
import LoadingSpinner from "../components/UI/LoadingSpinner";
import NoQuotesFound from "../components/quotes/NoQuotesFound";
import useHttp from "../hooks/use-http";
import { getAllQuotes } from "../lib/api";

const AllQuotes = () => {
  // Initiate hook
  const {
    sendRequest,
    status,
    data: loadedQuotes, // alias for data
    error,
  } = useHttp(
    getAllQuotes, // function from api.js
    true // initial status is "pending"
  );

  // This will execute initially
  useEffect(() => {
    sendRequest(); // fetch all quotes from the API
  }, [sendRequest]);
  // set dependency (As a good practice)

  // If the status is "pending" show spinner
  if (status === "pending") {
    return (
      <div className="centered">
        <LoadingSpinner />
      </div>
    );
  }

  // If there is an error
  if (error) {
    return <p className="centered focused">{error}</p>;
  }

  // If there is no quotes
  if (status === "completed" && (!loadedQuotes || loadedQuotes.length === 0)) {
    return <NoQuotesFound />;
  }

  // show quotes
  return <QuoteList quotes={loadedQuotes} />;
};

export default AllQuotes;
