import { useReducer, useCallback } from "react";

function httpReducer(state, action) {
  // While sending the request
  if (action.type === "SEND") {
    return {
      data: null,
      error: null,
      status: "pending",
    };
  }

  // After send request successfully
  if (action.type === "SUCCESS") {
    return {
      data: action.responseData,
      error: null,
      status: "completed",
    };
  }

  // If there is an error while sending request
  if (action.type === "ERROR") {
    return {
      data: null,
      error: action.errorMessage,
      status: "completed",
    };
  }

  return state;
}

/*
  useHttp hook
  requestFunction => A function in api.js
  startWithPending => Optional
 */
function useHttp(requestFunction, startWithPending = false) {
  // Reducer state
  const [httpState, dispatch] = useReducer(httpReducer, {
    // set status as in the argument or null (When initially load - like fetching all the quotes)
    status: startWithPending ? "pending" : null,
    data: null,
    error: null,
  });

  /*
    A function in the hook
    We set it as a callback (sendRequest is use as a dependency in some places - like AllQuotes.js)
   */
  const sendRequest = useCallback(
    // requestData => argument
    (requestData) => {
      // set status as pending
      dispatch({ type: "SEND" });
      // send request to the API
      requestFunction(requestData)
        .then((responseData) => {
          // set data and status as success
          dispatch({ type: "SUCCESS", responseData });
        })
        .catch((error) => {
          // set error
          dispatch({
            type: "ERROR",
            errorMessage: error.message || "Something went wrong!",
          });
        });
    },
    [requestFunction] // dependency of the callback
  );

  // return sendRequest and state
  return {
    sendRequest,
    ...httpState,
  };
}

export default useHttp;
