import { useState, useEffect } from "react";

// name of the custom hook should be start from "use"
const useCounter = () => {
  // state (In here we just define state. Actually not allocate memory. Because this is just a func)
  const [counter, setCounter] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCounter((prevCounter) => prevCounter + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return counter; // return state
};

export default useCounter;

/*
  Custom hooks are just functions defined outside components. But inside that funcs we can use state 
  and call built in hooks.
 */
