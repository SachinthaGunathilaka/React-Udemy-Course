import Card from "./Card";
import useCounter from "../hooks/use-counter";

const ForwardCounter = () => {
  // Calling custom hook. return state from the useCounter will set to counter.
  const counter = useCounter();
  /*
    When calling custom hook, state define in custom hook allocate memory.
    (Not shared same state. Will create own state)
   */

  return <Card>{counter}</Card>; // display counter
};

export default ForwardCounter;
