// Check use-http.js,
import React, { useEffect, useState } from "react";

import Tasks from "./components/Tasks/Tasks";
import NewTask from "./components/NewTask/NewTask";
import useHttp from "./hooks/use-http";

function App() {
  // tasks state
  const [tasks, setTasks] = useState([]);

  // destruct useHttp() return values (And rename sendRequest as fetchTasks)
  const { isLoading, error, sendRequest: fetchTasks } = useHttp(); // initiate custom hook (No args in here)

  useEffect(() => {
    // tasksObj => incoming data
    const transformTasks = (tasksObj) => {
      const loadedTasks = [];

      for (const taskKey in tasksObj) {
        loadedTasks.push({ id: taskKey, text: tasksObj[taskKey].text });
      }
      // Set task state
      setTasks(loadedTasks);
    };

    // Call fetchTasks in the custom hook(With arguments)
    fetchTasks(
      { url: "https://react-http-6b4a6.firebaseio.com/tasks.json" }, // URL
      transformTasks // Callback function
    );
  }, [fetchTasks]);
  /*
      Set fetchTasks as a dependency. When executing transformTasks func, fetchTasks(sendRequest in hook) func will be executed.
      So the state in the hook will be changed. Therefore useHttp component will be re-evaluated. (Note: App also re evaluated)
      So new sendRequest(fetchTasks) object will be created. There will be infinite loop.
      To overcome that, we need to use, useCallback

   */

  /*
      Actually we dont need fetchTasks dependency. (Because it is never changes).
      As a good practice, all the functions(Except state changers) should be set as dependencies.
   */

  const taskAddHandler = (task) => {
    setTasks((prevTasks) => prevTasks.concat(task));
  };

  return (
    <React.Fragment>
      <NewTask onAddTask={taskAddHandler} />
      <Tasks
        items={tasks}
        loading={isLoading}
        error={error}
        onFetch={fetchTasks}
      />
    </React.Fragment>
  );
}

export default App;

// If the state in custom hook changes, The component that use the custom hook will be re evaluated.
// If isLoading or error state in use-http changes, App comp also re evaluated
