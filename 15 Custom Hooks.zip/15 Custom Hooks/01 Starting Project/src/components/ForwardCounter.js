import { useState, useEffect } from "react";

import Card from "./Card";

const ForwardCounter = () => {
  const [counter, setCounter] = useState(0);

  // We need to use useEffect (If not everytime state updates this will execute)
  useEffect(() => {
    // execute inner func after every 1s
    const interval = setInterval(() => {
      setCounter((prevCounter) => prevCounter + 1);
    }, 1000);

    // Clear func will execute when useEffect run again or when ForwardCounter comp unmounting
    return () => {
      console.log("Clear");
      return clearInterval(interval);
    };
  }, []);

  return <Card>{counter}</Card>;
};

export default ForwardCounter;
