// Check use-http.js, App.js

import React, { useEffect, useState } from "react";

import Tasks from "./components/Tasks/Tasks";
import NewTask from "./components/NewTask/NewTask";
import useHttp from "./hooks/use-http";

function App() {
  const [tasks, setTasks] = useState([]);

  // callback function
  const transformTasks = (tasksObj) => {
    const loadedTasks = [];
    for (const taskKey in tasksObj) {
      loadedTasks.push({ id: taskKey, text: tasksObj[taskKey].text });
    }
    setTasks(loadedTasks);
  };

  // Initiate custom hook
  const {
    isLoading, // state
    error, // state
    sendRequest: fetchTasks, // function
  } = useHttp(
    {
      url: "https://react-http-6b4a6.firebaseio.com/tasks.json", // URL
    },
    transformTasks // passing func
  );

  useEffect(() => {
    fetchTasks(); // call function in the hook (It will fetch data from the API, It will call transformTasks func, then tasks state will be updated. )
  }, []);

  const taskAddHandler = (task) => {
    setTasks((prevTasks) => prevTasks.concat(task));
  };

  return (
    <React.Fragment>
      <NewTask onAddTask={taskAddHandler} />
      <Tasks
        items={tasks}
        loading={isLoading}
        error={error}
        onFetch={fetchTasks}
      />
    </React.Fragment>
  );
}

export default App;
