import { useState } from "react";

// get requestConfig, applyData as args
const useHttp = (requestConfig, applyData) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const sendRequest = async () => {
    setIsLoading(true);
    setError(null);
    try {
      // Set URL and other configs from args with default values
      const response = await fetch(requestConfig.url, {
        method: requestConfig.method ? requestConfig.method : "GET",
        headers: requestConfig.headers ? requestConfig.headers : {},
        body: requestConfig.body ? JSON.stringify(requestConfig.body) : null,
      });

      if (!response.ok) {
        throw new Error("Request failed!");
      }

      const data = await response.json();

      // call function in the args with data
      applyData(data);
    } catch (err) {
      setError(err.message || "Something went wrong!");
    }
    setIsLoading(false);
  };

  // return state and sendRequest func
  return {
    isLoading, // isLoading : isLoading (This is the usual way, Both are similar)
    error,
    sendRequest,
  };
};

export default useHttp;

/*
  From a component if we call useHttp() hook =>
    Own state will be created. (isLoading, error)
    Own sendRequest() function object will be created. (But it will not execute, until it executed from the comp.)
    Because we have not called that func inside hook.
 */
