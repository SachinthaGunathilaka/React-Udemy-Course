import { useState, useEffect } from "react";

// custom hook with incoming argument (set default arg as true)
const useCounter = (forwards = true) => {
  const [counter, setCounter] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      // Conditionally set state
      if (forwards) {
        setCounter((prevCounter) => prevCounter + 1);
      } else {
        setCounter((prevCounter) => prevCounter - 1);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [forwards]);
  /* Set dependency as forwards
     Actually we dont need that. Because forward is incoming arg. It is not changed for a component.
   */

  return counter;
};

export default useCounter;
