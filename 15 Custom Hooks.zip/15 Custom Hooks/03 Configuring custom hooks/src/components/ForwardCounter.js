import Card from "./Card";
import useCounter from "../hooks/use-counter";

const ForwardCounter = () => {
  // call useCounter with no args
  const counter = useCounter();

  return <Card>{counter}</Card>;
};

export default ForwardCounter;
