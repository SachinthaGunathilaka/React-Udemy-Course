// Check App.js, NewTask.js, TaskForm.js, Tasks.js

import React, { useEffect, useState } from "react";

import Tasks from "./components/Tasks/Tasks";
import NewTask from "./components/NewTask/NewTask";

function App() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [tasks, setTasks] = useState([]);

  //fetch tasks
  const fetchTasks = async (taskText) => {
    setIsLoading(true);
    setError(null);
    try {
      // GET request for fetching tasks from API
      const response = await fetch(
        "https://react-http-6b4a6.firebaseio.com/tasks.json"
      );

      if (!response.ok) {
        throw new Error("Request failed!");
      }

      const data = await response.json();

      const loadedTasks = [];

      for (const taskKey in data) {
        loadedTasks.push({ id: taskKey, text: data[taskKey].text });
      }

      // set state
      setTasks(loadedTasks);
    } catch (err) {
      setError(err.message || "Something went wrong!");
    }
    setIsLoading(false);
  };

  // fetch tasks when start
  useEffect(() => {
    fetchTasks();
  }, []);

  // Passing function
  const taskAddHandler = (task) => {
    // add incoming task object to state
    setTasks((prevTasks) => prevTasks.concat(task));
  };

  return (
    <React.Fragment>
      {/* NewTask comp */}
      <NewTask onAddTask={taskAddHandler} />
      {/* All the tasks */}
      <Tasks
        items={tasks} // pass fetched tasks
        loading={isLoading} // pass loading
        error={error} // pass error
        onFetch={fetchTasks} // pass fetching func also
      />
    </React.Fragment>
  );
}

export default App;
