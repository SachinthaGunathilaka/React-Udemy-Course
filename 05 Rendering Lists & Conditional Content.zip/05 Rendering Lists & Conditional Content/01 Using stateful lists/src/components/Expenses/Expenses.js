import React, { useState } from 'react';

import ExpenseItem from './ExpenseItem';
import Card from '../UI/Card';
import ExpensesFilter from './ExpensesFilter';
import './Expenses.css';

const Expenses = (props) => {
  const [filteredYear, setFilteredYear] = useState('2020');

  const filterChangeHandler = (selectedYear) => {
    setFilteredYear(selectedYear);
  };

  return (
    <div>
      <Card className='expenses'>
        <ExpensesFilter
          selected={filteredYear}
          onChangeFilter={filterChangeHandler}
        />
        {/* Display all the items, jsx syntax (No return in needed in inline arrow funcs) */}

        {props.items.map((expense) => (
          <ExpenseItem
            key={expense.id} // Set key
            title={expense.title}
            amount={expense.amount}
            date={expense.date}
          />
        ))}
      </Card>
    </div>
  );
};

export default Expenses;

/*
  In react when we display list of items, we need to pass unique key for each item.
  If not when we updating or adding a item react will re evaluate all the items.
  Because react cannot identify exact item.
 */
