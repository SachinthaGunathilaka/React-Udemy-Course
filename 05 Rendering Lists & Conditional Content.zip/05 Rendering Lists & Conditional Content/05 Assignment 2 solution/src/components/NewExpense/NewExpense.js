import React, { useState } from 'react';

import ExpenseForm from './ExpenseForm';
import './NewExpense.css';

const NewExpense = (props) => {
  // Button handling state
  const [isEditing, setIsEditing] = useState(false);

  const saveExpenseDataHandler = (enteredExpenseData) => {
    const expenseData = {
      ...enteredExpenseData,
      id: Math.random().toString(),
    };
    props.onAddExpense(expenseData);
    setIsEditing(false);
  };

  // start editing handler
  const startEditingHandler = () => {
    // show editing form
    setIsEditing(true);
  };

  // stop editing handler
  const stopEditingHandler = () => {
    setIsEditing(false);
  };

  return (
    <div className='new-expense'>
      {/* If left condition is true, right expression(after &&) will be executed*/}

      {!isEditing && (
        <button onClick={startEditingHandler}>Add New Expense</button>
      )}
      {/* If left condition is true, right expression(after &&) will be executed*/}

      {isEditing && (
        <ExpenseForm
          onSaveExpenseData={saveExpenseDataHandler}
          // pass function as a prop
          onCancel={stopEditingHandler}
        />
      )}
    </div>
  );
};

export default NewExpense;
