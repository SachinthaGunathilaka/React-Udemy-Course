import ChartBar from './ChartBar';
import './Chart.css';

const Chart = (props) => {
  // Extract only values from object array.
  const dataPointValues = props.dataPoints.map(dataPoint => dataPoint.value);
  // get maximum valur
  const totalMaximum = Math.max(...dataPointValues); // Argument should be comma separated values

  return (
    <div className='chart'>
      {/* Separate ChartBar for each data point */}
      {props.dataPoints.map((dataPoint) => (
        <ChartBar
          key={dataPoint.label}  // unique key for each Chart bar
          value={dataPoint.value}
          maxValue={totalMaximum}
          label={dataPoint.label}
        />
      ))}
    </div>
  );
};

export default Chart;
