// Check App.js

import React, { useState } from "react";

import MoviesList from "./components/MoviesList";
import "./App.css";

function App() {
  const [movies, setMovies] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  // Instead of using .then().catch() for asynchronous codes we can use async, await also

  // Use async before the func name
  async function fetchMoviesHandler() {
    // Before start fetching data set Isloading to false
    setIsLoading(true);
    // wait until fetch data from API (temporary pause this func)
    const response = await fetch("https://swapi.dev/api/films/");
    // wait until convert to js object(temporary pause this func)
    const data = await response.json();

    // No need await in these funcs (Because these funcs does not return promises)
    const transformedMovies = data.results.map((movieData) => {
      return {
        id: movieData.episode_id,
        title: movieData.title,
        openingText: movieData.opening_crawl,
        releaseDate: movieData.release_date,
      };
    });
    // set movies state
    setMovies(transformedMovies);
    // Isloading to false
    setIsLoading(false);
  }

  return (
    <React.Fragment>
      <section>
        <button onClick={fetchMoviesHandler}>Fetch Movies</button>
      </section>
      <section>
        {/* Conditionally show movies */}
        {!isLoading && movies.length > 0 && <MoviesList movies={movies} />}
        {!isLoading && movies.length === 0 && <p>Found no movies.</p>}

        {/* Show loading text while fetching data */}
        {isLoading && <p>Loading...</p>}
      </section>
    </React.Fragment>
  );
}

export default App;
