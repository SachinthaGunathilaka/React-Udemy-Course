// Check App.js

import React, { useState } from "react";

import MoviesList from "./components/MoviesList";
import "./App.css";

function App() {
  // state for movies
  const [movies, setMovies] = useState([]);

  // Fetch movies
  function fetchMoviesHandler() {
    /*
        fetch takes 2 args => url , {other options like method, body}
        second arg is optional (default method is GET)

        fetch returns => a promise
     */

    /*
         This API sends response as json format
         Note that despite the method being named json(), the result is not JSON.
         Instead it is taking JSON as input and return a JavaScript object.  
     */

    fetch("https://swapi.dev/api/films/")
      .then((response) => {
        // return js object
        return response.json();
      })
      .then((data) => {
        // convert incoming data to the form that we need
        const transformedMovies = data.results.map((movieData) => {
          return {
            id: movieData.episode_id,
            title: movieData.title,
            openingText: movieData.opening_crawl,
            releaseDate: movieData.release_date,
          };
        });
        // set state
        setMovies(transformedMovies);
      });
  }

  return (
    <React.Fragment>
      <section>
        {/* When click the button, movies will be fetch from the API */}
        <button onClick={fetchMoviesHandler}>Fetch Movies</button>
      </section>
      <section>
        <MoviesList movies={movies} />
      </section>
    </React.Fragment>
  );
}

export default App;
