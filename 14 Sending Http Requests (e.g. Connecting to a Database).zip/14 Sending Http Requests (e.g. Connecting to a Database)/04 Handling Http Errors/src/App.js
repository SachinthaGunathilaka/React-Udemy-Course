// Check App.js

import React, { useState } from "react";

import MoviesList from "./components/MoviesList";
import "./App.css";

function App() {
  const [movies, setMovies] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  // Error state
  const [error, setError] = useState(null);

  async function fetchMoviesHandler() {
    setIsLoading(true);
    // clear previous errors
    setError(null);
    /*
        Set url to invalid url. It will not give technical error. We will receive response with error status code.
        So we need to check status code manually or check ok prop in the response and throw error.
        Therefore we need try catch.

        If we use .then().catch() =>
          It will not give technical error. We will receive response with error status code.
          So we need to check status code manually or check ok prop in the response and throw error.
          The the error will catch from .catch()

        If we use Axios, it will automatically throw error when we got error status codes. No need to throw.
        Can access the error in catch block
     */

    try {
      const response = await fetch("https://swapi.dev/api/film/");

      // Throw error if the status code is not valid
      if (!response.ok) {
        throw new Error("Something went wrong");
      }
      const data = await response.json();

      const transformedMovies = data.results.map((movieData) => {
        return {
          id: movieData.episode_id,
          title: movieData.title,
          openingText: movieData.opening_crawl,
          releaseDate: movieData.release_date,
        };
      });
      setMovies(transformedMovies);
    } catch (error) {
      // Set error as the message we give above
      setError(error.message);
    }

    // set loading to false whether we got error or not
    setIsLoading(false);
  }

  // Generate content dynamically
  let content = <p>Found no movies.</p>;
  if (movies.length > 0) {
    content = <MoviesList movies={movies} />;
  }
  if (error) {
    content = <p>{error}</p>;
  }
  if (isLoading) {
    content = <p>Loading...</p>;
  }

  return (
    <React.Fragment>
      <section>
        <button onClick={fetchMoviesHandler}>Fetch Movies</button>
      </section>
      <section>{content}</section>
    </React.Fragment>
  );
}

export default App;
