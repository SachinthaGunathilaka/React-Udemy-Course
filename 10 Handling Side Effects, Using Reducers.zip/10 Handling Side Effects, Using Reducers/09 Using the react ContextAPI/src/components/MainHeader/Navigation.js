import React from 'react';

import AuthContext from '../../store/auth-context';
import classes from './Navigation.module.css';

const Navigation = (props) => {
  return (
      // Inside a child comp, to use AuthContext data, we need to wrap the comp by using AuthContext.Consumer
    <AuthContext.Consumer>
      {/* This is a callback func, ctx holds the data, Inside that we need to return the content */}
      {(ctx) => {
        return (
          <nav className={classes.nav}>
            <ul>
              {/* Access AuthContext data */}
              {ctx.isLoggedIn && (
                <li>
                  <a href="/">Users</a>
                </li>
              )}
              {ctx.isLoggedIn && (
                <li>
                  <a href="/">Admin</a>
                </li>
              )}
              {ctx.isLoggedIn && (
                <li>
                  <button onClick={props.onLogout}>Logout</button>
                </li>
              )}
            </ul>
          </nav>
        );
      }}
    </AuthContext.Consumer>
  );
};

export default Navigation;
