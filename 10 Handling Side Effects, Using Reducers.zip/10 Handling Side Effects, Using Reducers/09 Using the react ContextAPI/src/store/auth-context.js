import React from 'react';

// Create context (In here we use object)
// AuthContext contains a component (We can extract it by AuthContext.Provider)
const AuthContext = React.createContext({
  isLoggedIn: false // data
});

export default AuthContext;

// Parent component is wrapped by AuthContext.Provider (In here our parent comp is App)
// Child component is wrapped by AuthContext.Consumer