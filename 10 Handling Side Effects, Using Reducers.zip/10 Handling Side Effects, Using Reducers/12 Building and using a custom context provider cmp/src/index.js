import React from 'react';
import ReactDOM from 'react-dom';

import './index.css';
import App from './App';
import { AuthContextProvider } from './store/auth-context';

ReactDOM.render(
    // Wrap with AuthContextProvider
    // Our parent comp is App, all other components are child(App is the top level component)
    // So all other comps can access AuthContext
  <AuthContextProvider>
    <App />
  </AuthContextProvider>,
  document.getElementById('root')
);
