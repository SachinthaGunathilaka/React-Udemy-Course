// Check App.js, MainHeader.js, Navigation.js, Login.js, Home.js

import React, { useState } from 'react';

import Login from './components/Login/Login';
import Home from './components/Home/Home';
import MainHeader from './components/MainHeader/MainHeader';

function App() {

    // login state (Initially false)
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // log in handler (get email and password from child)
  const loginHandler = (email, password) => {
    // We should of course check email and password
    // But it's just a dummy/ demo anyways
    setIsLoggedIn(true); // set log in state as true
  };

  // log out handler
  const logoutHandler = () => {
    setIsLoggedIn(false); // set log in state as false
  };

  return (
    <React.Fragment>
      {/* Main header component, pass authentication and log out function */}
      <MainHeader isAuthenticated={isLoggedIn} onLogout={logoutHandler} />
      <main>
        {!isLoggedIn && <Login onLogin={loginHandler} />}  {/* If user not logged in, show log in page */}
        {isLoggedIn && <Home onLogout={logoutHandler} />}  {/* If user logged in, show home page */}

      </main>
    </React.Fragment>
  );
}

export default App;
