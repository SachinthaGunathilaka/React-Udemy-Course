import React, { useState } from 'react';

import Card from '../UI/Card/Card';
import classes from './Login.module.css';
import Button from '../UI/Button/Button';

const Login = (props) => {

  // States
  const [enteredEmail, setEnteredEmail] = useState('');
  const [emailIsValid, setEmailIsValid] = useState(); // validity of the email
  const [enteredPassword, setEnteredPassword] = useState('');
  const [passwordIsValid, setPasswordIsValid] = useState(); // validity of the password
  const [formIsValid, setFormIsValid] = useState(false); // validity of the form

  // when changing email field
  const emailChangeHandler = (event) => {
    setEnteredEmail(event.target.value); // set email state

    // set form validity (true / false)
    setFormIsValid(
      event.target.value.includes('@') && enteredPassword.trim().length > 6
    );
  };

  // when changing password field
  const passwordChangeHandler = (event) => {
    setEnteredPassword(event.target.value); // set password state

    // set form validity (true / false)
    setFormIsValid(
      event.target.value.trim().length > 6 && enteredEmail.includes('@')
    );
  };

  //  after enter input and leave the field
  const validateEmailHandler = () => {
    setEmailIsValid(enteredEmail.includes('@'));
  };

  //  after enter input and leave the field
  const validatePasswordHandler = () => {
    setPasswordIsValid(enteredPassword.trim().length > 6);
  };

  // submit handler function
  const submitHandler = (event) => {
    event.preventDefault();
    props.onLogin(enteredEmail, enteredPassword); // call the function in the prop
  };

  return (
    <Card className={classes.login}>
      {/* form submitting function */}
      <form onSubmit={submitHandler}>
        <div
          className={`${classes.control} ${
            emailIsValid === false ? classes.invalid : ''
          }`}
        >
          <label htmlFor="email">E-Mail</label>
          <input
            type="email"
            id="email"
            value={enteredEmail} // 2 way binding
            onChange={emailChangeHandler} // when entering input
            onBlur={validateEmailHandler} // after enter input and leave the field (opposite of onFocus)
          />
        </div>

        <div
          className={`${classes.control} ${
            passwordIsValid === false ? classes.invalid : ''
          }`}
        >
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={enteredPassword} // 2 way binding
            onChange={passwordChangeHandler} // when entering input
            onBlur={validatePasswordHandler} // after enter input and leave the field (opposite of onFocus)
          />
        </div>
        <div className={classes.actions}>
          {/* Submitting form is disabled if the form is not valid*/}
          <Button type="submit" className={classes.btn} disabled={!formIsValid}>
            Login
          </Button>
        </div>
      </form>
    </Card>
  );
};

export default Login;
