import React from 'react';

const AuthContext = React.createContext({
  // no default value for func (Thats okay)
  isLoggedIn: false
});

export default AuthContext;