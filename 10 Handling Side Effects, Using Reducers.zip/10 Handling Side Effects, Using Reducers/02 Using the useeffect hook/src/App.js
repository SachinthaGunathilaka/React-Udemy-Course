// Check App.js

// Import useEffect Hook
import React, { useState, useEffect } from 'react';

import Login from './components/Login/Login';
import Home from './components/Home/Home';
import MainHeader from './components/MainHeader/MainHeader';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // useEffect (function, array of dependencies)
  // When the App starts , all of them run (Not checking dependencies)
  useEffect(() => {
    // Get data from browser local storage
    const storedUserLoggedInInformation = localStorage.getItem('isLoggedIn');

    if (storedUserLoggedInInformation === '1') {
      setIsLoggedIn(true); // set isLoggedIn state to true
      // In we are not using useEffect(), this will create a infinite loop(Because when state updating whole component re-evaluating)
    }
    // no dependencies (Only execute when app starts)
  }, []);

  const loginHandler = (email, password) => {

    // Browser has many storages like cookie, local storage (In here we use local storage)
    // Browser => Inspect => Application => Local Storage
    //                    key         value
    localStorage.setItem('isLoggedIn', '1');
    setIsLoggedIn(true);
  };

  const logoutHandler = () => {
    localStorage.removeItem('isLoggedIn');
    setIsLoggedIn(false);
  };

  return (
    <React.Fragment>
      <MainHeader isAuthenticated={isLoggedIn} onLogout={logoutHandler} />
      <main>
        {!isLoggedIn && <Login onLogin={loginHandler} />}
        {isLoggedIn && <Home onLogout={logoutHandler} />}
      </main>
    </React.Fragment>
  );
}

export default App;
